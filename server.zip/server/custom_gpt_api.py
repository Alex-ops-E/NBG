from fastapi import FastAPI, Request
from pydantic import BaseModel
import os
import json
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health-check")
async def health_check():
    return {"status": "ok"}

# Model for ingredient input with quantities (our app format)
class Ingredient(BaseModel):
    item: str
    quantity: str

class IngredientsRequest(BaseModel):
    ingredients: list[Ingredient]

# Simple response model for custom GPT
class SimpleIngredientsResponse(BaseModel):
    ingredients: list[str]

@app.post("/custom-gpt-ingredients")
async def get_ingredients_for_custom_gpt(req: IngredientsRequest):
    """
    Takes a list of ingredients with quantities and returns just the ingredient names
    for use with a custom GPT
    """
    try:
        # Extract just the ingredient names (no quantities)
        ingredient_names = [ing.item for ing in req.ingredients if ing.item.strip()]
        
        # Return the simplified list
        return SimpleIngredientsResponse(ingredients=ingredient_names)
        
    except Exception as e:
        print(f"Error processing ingredients for custom GPT: {str(e)}")
        return {"error": f"Failed to process ingredients: {str(e)}"}

# Start the server if run directly
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)  # Use a different port than the main API