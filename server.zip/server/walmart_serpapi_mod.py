import requests
import os
import re

def search_walmart_serpapi(ingredient_name):
    """
    Search for price of an ingredient from Walmart using SerpAPI
    Returns live product data with accurate pricing and direct product link
    """
    try:
        # Format the query for better results - remove quantity, units or other non-essential terms
        query_terms = ingredient_name.lower()
        # Remove specific quantities like '2 lb', '16 oz' etc.
        query_terms = re.sub(r'\d+\s*(oz|ounce|lb|pound|pack|g|gram|kg|ml|l|liter|count|ct)', '', query_terms)
        # Remove packaging terms
        query_terms = re.sub(r'(package|box|jar|bottle|can|container|pack)', '', query_terms)
        # Remove words like "fresh", "frozen", etc.
        query_terms = re.sub(r'(fresh|frozen|organic|natural|raw|cooked|prepared)', '', query_terms)
        # Clean up extra spaces
        query_terms = re.sub(r'\s+', ' ', query_terms).strip()
        
        # If the query is too short after cleaning, use the original ingredient name
        if len(query_terms) < 3:
            query_terms = ingredient_name
        
        # SerpAPI URL and API Key
        url = "https://serpapi.com/search.json"
        api_key = os.environ.get("SERPAPI_KEY")
        
        if not api_key:
            print("SERPAPI_KEY environment variable not set")
            return {"error": "API key for Walmart search is not configured"}
        
        # Set up query parameters for Walmart search
        params = {
            "engine": "walmart",
            "query": query_terms,
            "api_key": api_key,
            "sort": "price_low",  # Sort by lowest price first
            "output": "json"
        }
        
        # Make API request and get results
        response = requests.get(url, params=params)
        
        # If request was not successful, return error
        if response.status_code != 200:
            print(f"SerpAPI error for Walmart product search: {response.status_code} - {response.text}")
            return {"error": f"Could not find {ingredient_name} at Walmart"}
            
        data = response.json()
        organic_results = data.get("organic_results", [])
            
        # If we have products, process them
        if organic_results:
            # First look for "popular pick" badge products
            popular_picks = []
            best_sellers = []
            
            for p in organic_results:
                # Check for badges in different formats
                badge = p.get("badge", "")
                if badge and isinstance(badge, str):
                    if "Popular Pick" in badge:
                        popular_picks.append(p)
                    elif "Best Seller" in badge:
                        best_sellers.append(p)
                elif isinstance(badge, list):
                    for b in badge:
                        if isinstance(b, str) and "Popular Pick" in b:
                            popular_picks.append(p)
                        elif isinstance(b, str) and "Best Seller" in b:
                            best_sellers.append(p)
            
            # Select the product, prioritizing popular picks, then best sellers, then first product
            product = None
            if popular_picks:
                product = popular_picks[0]
            elif best_sellers:
                product = best_sellers[0]
            else:
                product = organic_results[0]
            
            # Extract product details
            title = product.get("title", ingredient_name)
            
            # Try to extract price
            price = None
            primary_offer = product.get("primary_offer", {})
            if isinstance(primary_offer, dict) and "offer_price" in primary_offer:
                price = float(primary_offer["offer_price"])
            else:
                # Try alternative ways to get price
                price_str = product.get("price", "")
                if price_str and isinstance(price_str, str) and "$" in price_str:
                    try:
                        price_str = price_str.replace("$", "").replace(",", "").strip()
                        price = float(price_str)
                    except ValueError:
                        pass
                        
            if price is None:
                return {"error": f"No valid price found for {ingredient_name} at Walmart"}
                
            # Get product URL
            product_url = product.get("product_page_url", "")
            if not product_url:
                product_url = f"https://www.walmart.com/search?q={ingredient_name.replace(' ', '+')}"
            
            # Get size if available
            size = None
            if "quantity" in product:
                size = product["quantity"]
            elif "specifications" in product:
                for spec in product.get("specifications", []):
                    if spec.get("key", "").lower() in ["size", "weight", "count", "quantity"]:
                        size = spec.get("value", "")
                        break
            
            if not size:
                size = "Standard size"
                
            # Get price per unit if available
            price_per_unit = None
            if "price_per_unit" in product:
                price_per_unit = product["price_per_unit"]
            elif "unit_price" in product:
                price_per_unit = product["unit_price"]
            
            # Build result
            result = {
                "title": title,
                "price": price,
                "url": product_url,
                "size": size
            }
            
            # Add price per unit if available
            if price_per_unit:
                result["pricePerUnit"] = price_per_unit
            
            return result
        
        # If no products found, return error
        return {"error": f"Could not find {ingredient_name} at Walmart"}
        
    except Exception as e:
        print(f"Error in Walmart SerpAPI search: {str(e)}")
        return {"error": f"Error searching for {ingredient_name} at Walmart: {str(e)}"}


# Example testing code
if __name__ == "__main__":
    test_ingredients = ["apples", "milk 1 gallon", "pasta", "eggs 12 count", "oatmeal"]
    for ingredient in test_ingredients:
        print(f"\nSearching for: {ingredient}")
        result = search_walmart_serpapi(ingredient)
        print(result)