import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import fs from "fs";
import path from "path";

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: false, limit: '10mb' }));

// Add CORS headers to all responses
app.use((req, res, next) => {
  // Allow requests from any origin
  res.header("Access-Control-Allow-Origin", "*");
  // Allow specific headers
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  // Allow specific methods
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  // Allow credentials
  res.header("Access-Control-Allow-Credentials", "true");
  // Expose headers
  res.header("Access-Control-Expose-Headers", "Content-Length, X-JSON");
  
  // Handle preflight requests
  if (req.method === "OPTIONS") {
    console.log(`Preflight request from ${req.headers.origin || 'unknown origin'}`);
    return res.status(200).end();
  }
  
  console.log(`Incoming request: ${req.method} ${req.path} from ${req.headers.origin || 'unknown origin'}`);
  next();
});

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Health check endpoint for deployment monitoring
app.get('/health', (req, res) => {
  const healthCheck = {
    status: 'healthy',
    uptime: process.uptime(),
    message: 'OK',
    timestamp: Date.now(),
    environment: process.env.NODE_ENV || 'development',
    port: process.env.PORT || 8080 ,
    deployment: process.env.REPLIT_DEPLOYMENT_ID ? 'active' : 'development',
    server_info: {
      express_env: req.app.get('env'),
      node_version: process.version,
      hostname: req.hostname,
      protocol: req.protocol
    }
  };
  
  try {
    res.status(200).json(healthCheck);
  } catch (error) {
    healthCheck.status = 'error';
    healthCheck.message = error instanceof Error ? error.message : 'Unknown error';
    res.status(503).json(healthCheck);
  }
});

// Enhanced error handling for deployment
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  if (process.env.NODE_ENV === 'production') {
    process.exit(1);
  }
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  if (process.env.NODE_ENV === 'production') {
    process.exit(1);
  }
});

(async () => {
  // ULTRA-AGGRESSIVE DEPLOYMENT DETECTION - Force production mode in ANY deployment-like environment
  const isGCEDeployment = process.env.REPLIT_DEPLOYMENT_ID || 
                         process.env.NODE_ENV === 'production' || 
                         process.env.DISABLE_PYTHON_SERVICES === 'true' ||
                         process.env.GCE_ENV === 'true' ||
                         process.env.REPL_DEPLOYMENT === 'true' ||
                         process.env.VERCEL === '1' ||
                         process.env.NETLIFY === 'true' ||
                         process.env.GAE_INSTANCE ||
                         process.env.K_SERVICE ||
                         process.env.CLOUD_RUN_JOB ||
                         // Remove port-based detection to respect process.env.PORT
                         // Detect if we're in a containerized environment
                         process.env.KUBERNETES_SERVICE_HOST ||
                         // Default to deployment mode if no development indicators present
                         (!process.env.REPL_ID && !process.env.npm_config_user_config);
  
  if (isGCEDeployment) {
    process.env.NODE_ENV = 'production';
    process.env.DISABLE_PYTHON_SERVICES = 'true';
    // Force app environment to production immediately
    app.set('env', 'production');
    console.log("🚀 === NUCLEAR DEPLOYMENT MODE ACTIVATED ===");
    console.log("✅ NODE_ENV=production FORCED");
    console.log("✅ DISABLE_PYTHON_SERVICES=true FORCED");
    console.log("✅ EXPRESS ENV=production FORCED");
    console.log("✅ PYTHON SERVICES WILL BE COMPLETELY BYPASSED");
    console.log("✅ ULTRA-FAST STARTUP MODE ENGAGED");
    console.log(`📊 Final Environment: NODE_ENV=${process.env.NODE_ENV}, EXPRESS=${app.get('env')}`);
    console.log(`📊 Deployment ID: ${process.env.REPLIT_DEPLOYMENT_ID || 'auto-detected'}`);
    console.log("🚀 === GUARANTEED SUB-30-SECOND STARTUP ===");
  }

  // Set environment variable for Python servers to bind to correct interface
  if (!process.env.PYTHON_SERVER_HOST) {
    process.env.PYTHON_SERVER_HOST = "0.0.0.0";
    console.log("Setting PYTHON_SERVER_HOST to 0.0.0.0 for deployment compatibility");
  }
  
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // CRITICAL FIX: Use proper port detection for GCE deployment
  // In GCE deployment, process.env.PORT is set by the deployment environment (usually 8080)
  // For development, fallback to 5000 to avoid conflicts with Python services
  const port = parseInt(process.env.PORT || (isGCEDeployment ? '8080' : '5000'), 10);
  
  const host = "0.0.0.0"; // Always bind to all interfaces for external access
  
  log(`Port configuration: deployment=${process.env.PORT || 'not set'}, using=${port}`);
  log(`Environment: NODE_ENV=${process.env.NODE_ENV}, deployment=${isGCEDeployment}`);
  
  // Extra logging for deployment debugging
  if (isGCEDeployment) {
    log(`🚀 DEPLOYMENT MODE: Port ${port} selected for GCE deployment`);
    log(`🚀 DEPLOYMENT MODE: Environment variables - REPLIT_DEPLOYMENT_ID=${process.env.REPLIT_DEPLOYMENT_ID}, GCE_ENV=${process.env.GCE_ENV}`);
  }

  // Enhanced server startup with better error handling
  server.on('error', (error: NodeJS.ErrnoException) => {
    console.error('=== SERVER STARTUP ERROR ===');
    console.error('Error Code:', error.code);
    console.error('Error Message:', error.message);
    console.error('Stack:', error.stack);
    console.error('Port:', port);
    console.error('Host:', host);
    console.error('NODE_ENV:', process.env.NODE_ENV);
    console.error('REPLIT_DEPLOYMENT_ID:', process.env.REPLIT_DEPLOYMENT_ID);
    console.error('Process PORT:', process.env.PORT);
    console.error('Express env:', app.get('env'));
    console.error('============================');
    
    if (error.code === 'EADDRINUSE') {
      log(`ERROR: Port ${port} is already in use. Try a different port.`);
      process.exit(1);
    } else if (error.code === 'EACCES') {
      log(`ERROR: Permission denied to bind to port ${port}. Try a different port.`);
      process.exit(1);
    } else {
      log(`ERROR: Server error: ${error.message}`);
      process.exit(1);
    }
  });

  // Add pre-startup validation
  console.log('=== PRE-STARTUP VALIDATION ===');
  console.log(`Node.js version: ${process.version}`);
  console.log(`Working directory: ${process.cwd()}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`Deployment ID: ${process.env.REPLIT_DEPLOYMENT_ID || 'not set'}`);
  console.log(`Target port: ${port} (from PORT=${process.env.PORT || 'not set'})`);
  console.log(`Target host: ${host}`);
  console.log(`Express mode: ${app.get('env')}`);
  console.log('==============================');

  server.listen(port, host, () => {
    log(`✓ Server running in ${app.get('env')} mode on http://${host}:${port}`);
    log(`✓ Health check available at http://${host}:${port}/health`);
    log(`✓ Environment: NODE_ENV=${process.env.NODE_ENV}, REPLIT_DEPLOYMENT_ID=${process.env.REPLIT_DEPLOYMENT_ID || 'not set'}`);
    
    // Validate server is actually reachable
    setTimeout(async () => {
      try {
        const response = await fetch(`http://${host === '0.0.0.0' ? 'localhost' : host}:${port}/health`);
        if (response.ok) {
          console.log('✓ SELF-CHECK: Health endpoint responding correctly');
        } else {
          console.error(`✗ SELF-CHECK: Health endpoint returned status ${response.status}`);
        }
      } catch (error) {
        console.error('✗ SELF-CHECK: Failed to reach health endpoint:', error instanceof Error ? error.message : 'Unknown error');
      }
    }, 1000);
    
    // Log deployment-specific information
    if (isGCEDeployment) {
      log(`✓ DEPLOYMENT MODE: GCE/Production deployment detected`);
      log(`✓ PYTHON SERVICES: Disabled for ultra-fast startup and reliability`);
      log(`✓ PORT: ${port} (using process.env.PORT=${process.env.PORT || 'not set, using 5000'})`);
      log(`✓ GCE DEPLOYMENT: Server successfully bound to ${host}:${port}`);
      log(`✓ DEPLOYMENT READY: Server listening on ${host}:${port}`);
      log(`✓ HEALTH CHECK: ${host}:${port}/health`);
      log(`✓ GCE READY: Application is ready to receive traffic`);
    } else {
      log(`✓ DEVELOPMENT MODE: Full-service development environment`);
      log(`✓ PYTHON SERVICES: Enabled for development and testing`);
      log(`✓ PORT: ${port} (development default)`);
    }
    
    // Log success message for deployment monitoring
    log(`✓ Application startup completed successfully`);
  });
})();
