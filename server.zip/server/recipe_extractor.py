from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import re
import uvicorn

app = FastAPI()

class RecipeRequest(BaseModel):
    recipe: str

class IngredientsResponse(BaseModel):
    ingredients: List[str]

def extract_ingredients_from_recipe(recipe_text: str) -> List[str]:
    """
    Extract ingredients from a recipe text using pattern matching
    This is a simple extraction method that works without requiring OpenAI
    """
    ingredients = []
    lines = recipe_text.split('\n')
    
    # Common ingredient line patterns
    ingredient_patterns = [
        r'^[-•*]\s*(.+)',  # Lines starting with bullet points
        r'^\d+\.?\s*(.+)',  # Lines starting with numbers
        r'^(\d+(?:\.\d+)?\s*(?:cups?|cup|tbsp|tsp|tablespoons?|teaspoons?|oz|ounces?|lbs?|pounds?|g|grams?|kg|ml|l|liters?|gallons?|pints?|quarts?)\s+.+)',  # Lines with measurements
    ]
    
    # Keywords that often indicate ingredient sections
    ingredient_section_markers = [
        'ingredients:', 'ingredient list:', 'you will need:', 'shopping list:', 'what you need:'
    ]
    
    in_ingredient_section = False
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Check if we're entering an ingredient section
        line_lower = line.lower()
        if any(marker in line_lower for marker in ingredient_section_markers):
            in_ingredient_section = True
            continue
            
        # Stop if we hit common non-ingredient sections
        if any(section in line_lower for section in ['instructions:', 'directions:', 'method:', 'preparation:', 'steps:']):
            in_ingredient_section = False
            continue
        
        # Extract ingredients using patterns
        ingredient_found = False
        for pattern in ingredient_patterns:
            match = re.match(pattern, line, re.IGNORECASE)
            if match:
                ingredient = match.group(1).strip()
                if ingredient and len(ingredient) > 2:  # Basic validation
                    ingredients.append(clean_ingredient(ingredient))
                    ingredient_found = True
                    break
        
        # If we're in an ingredient section and haven't found a pattern match,
        # but the line looks like an ingredient, include it
        if in_ingredient_section and not ingredient_found and is_likely_ingredient(line):
            ingredients.append(clean_ingredient(line))
    
    # If we didn't find ingredients with structured patterns, try a more general approach
    if not ingredients:
        ingredients = extract_ingredients_fallback(recipe_text)
    
    # Remove duplicates while preserving order
    seen = set()
    unique_ingredients = []
    for ingredient in ingredients:
        if ingredient.lower() not in seen:
            seen.add(ingredient.lower())
            unique_ingredients.append(ingredient)
    
    return unique_ingredients[:20]  # Limit to 20 ingredients max

def clean_ingredient(ingredient: str) -> str:
    """Clean up extracted ingredient text"""
    # Remove extra whitespace
    ingredient = re.sub(r'\s+', ' ', ingredient).strip()
    
    # Remove common prefixes/suffixes that aren't part of the ingredient
    ingredient = re.sub(r'^(for|to taste|as needed|optional)\s*[:-]?\s*', '', ingredient, flags=re.IGNORECASE)
    ingredient = re.sub(r'\s*\(.*?\)$', '', ingredient)  # Remove parenthetical notes at the end
    
    # Capitalize first letter
    if ingredient:
        ingredient = ingredient[0].upper() + ingredient[1:]
    
    return ingredient

def is_likely_ingredient(line: str) -> bool:
    """Check if a line is likely to be an ingredient"""
    line_lower = line.lower()
    
    # Common food words that indicate ingredients
    food_words = [
        'chicken', 'beef', 'pork', 'fish', 'salmon', 'tuna',
        'flour', 'sugar', 'salt', 'pepper', 'oil', 'butter',
        'onion', 'garlic', 'tomato', 'potato', 'carrot',
        'milk', 'cream', 'cheese', 'egg', 'bread',
        'rice', 'pasta', 'noodles', 'beans', 'corn',
        'apple', 'banana', 'lemon', 'lime', 'orange',
        'herbs', 'spices', 'sauce', 'stock', 'broth'
    ]
    
    # Check if line contains food words
    has_food_words = any(word in line_lower for word in food_words)
    
    # Check if line has measurement indicators
    has_measurements = bool(re.search(r'\d+(?:\.\d+)?\s*(?:cups?|tbsp|tsp|oz|lbs?|g|kg|ml|l)', line_lower))
    
    # Should be reasonably short (ingredients are usually not paragraphs)
    is_reasonable_length = 3 < len(line) < 100
    
    # Shouldn't look like instructions
    instruction_words = ['heat', 'cook', 'bake', 'fry', 'mix', 'stir', 'add', 'combine', 'place', 'remove']
    looks_like_instruction = any(line_lower.startswith(word) for word in instruction_words)
    
    return (has_food_words or has_measurements) and is_reasonable_length and not looks_like_instruction

def extract_ingredients_fallback(recipe_text: str) -> List[str]:
    """Fallback method to extract ingredients from unstructured text"""
    ingredients = []
    
    # Look for measurement patterns followed by ingredients
    measurement_pattern = r'(\d+(?:\.\d+)?\s*(?:cups?|cup|tbsp|tsp|tablespoons?|teaspoons?|oz|ounces?|lbs?|pounds?|g|grams?|kg|ml|l|liters?)\s+[^.!?]+?)(?=[.!?\n]|$)'
    
    matches = re.findall(measurement_pattern, recipe_text, re.IGNORECASE)
    for match in matches:
        ingredient = clean_ingredient(match.strip())
        if ingredient:
            ingredients.append(ingredient)
    
    return ingredients

@app.post("/extract-ingredients", response_model=IngredientsResponse)
async def extract_ingredients(request: RecipeRequest):
    """Extract ingredients from a recipe text"""
    if not request.recipe or not request.recipe.strip():
        raise HTTPException(status_code=400, detail="Recipe text is required")
    
    try:
        ingredients = extract_ingredients_from_recipe(request.recipe)
        
        if not ingredients:
            raise HTTPException(status_code=400, detail="No ingredients could be extracted from the recipe")
        
        return IngredientsResponse(ingredients=ingredients)
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error extracting ingredients: {str(e)}")

@app.get("/health-check")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "recipe_extractor"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8002)