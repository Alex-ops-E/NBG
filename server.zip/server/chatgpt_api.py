from fastapi import FastAPI, Request
from pydantic import BaseModel
import requests
import os
import openai
import json

app = FastAPI()

# Model for ingredient input without quantities
class IngredientsRequest(BaseModel):
    ingredients: list[str]

# Initialize OpenAI client (only if API key is available)
api_key = os.environ.get("OPENAI_API_KEY")
client = None
if api_key:
    try:
        client = openai.OpenAI(api_key=api_key)
    except Exception as e:
        print(f"Warning: Failed to initialize OpenAI client: {e}")
        # Continue without OpenAI functionality

@app.post("/generate-recipes")
async def generate_recipes(req: IngredientsRequest):
    """
    Takes a list of ingredients (without quantities) and uses ChatGPT to generate recipe suggestions
    """
    try:
        # Check if OpenAI client and API key are available
        if not client or not os.environ.get("OPENAI_API_KEY"):
            # Return fallback response with a friendly message
            fallback_response = {
                "recipes": [
                    {
                        "name": "Recipe Generator Unavailable",
                        "description": "The recipe generation feature requires an OpenAI API key which is not configured.",
                        "ingredients": [
                            {"name": "OpenAI API Key", "have": False, "amount": "1"}
                        ],
                        "steps": [
                            "This feature requires an OpenAI API key to work.",
                            "Please try the price comparison feature instead, which doesn't require an API key."
                        ]
                    }
                ]
            }
            return {"result": json.dumps(fallback_response)}
        
        # Join the ingredients into a comma-separated list
        ingredient_list = ", ".join(req.ingredients)
        
        # Create prompt for ChatGPT
        prompt = f"""
        I have the following ingredients: {ingredient_list}.
        
        Please suggest 3 recipes I can make with some or all of these ingredients.
        For each recipe, include:
        - Recipe name
        - Brief description
        - Ingredients needed (noting which ones I already have and which I would need to buy)
        - Basic preparation steps
        
        Format the response as a JSON object with this structure:
        {{
          "recipes": [
            {{
              "name": "Recipe Name",
              "description": "Brief description",
              "ingredients": [
                {{ "name": "Ingredient 1", "have": true, "amount": "1 cup" }},
                {{ "name": "Ingredient 2", "have": false, "amount": "2 tablespoons" }}
              ],
              "steps": ["Step 1", "Step 2", "Step 3"]
            }}
          ]
        }}
        """
        
        # Call OpenAI API
        response = client.chat.completions.create(
            model="gpt-4o", # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[
                {"role": "system", "content": "You are a helpful assistant that provides recipe suggestions based on available ingredients."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"}
        )
        
        # Extract and parse the response
        result = response.choices[0].message.content
        
        # Return the response directly (it's already in JSON format)
        return {"result": result}
        
    except Exception as e:
        print(f"Error in OpenAI API call: {str(e)}")
        fallback_response = {
            "recipes": [
                {
                    "name": "Error in Recipe Generator",
                    "description": f"An error occurred: {str(e)}",
                    "ingredients": [
                        {"name": "Error Details", "have": False, "amount": str(e)}
                    ],
                    "steps": [
                        "The recipe generation feature encountered an error.",
                        "Please try the price comparison feature instead."
                    ]
                }
            ]
        }
        return {"result": json.dumps(fallback_response)}

# Additional endpoint for meal planning
@app.post("/meal-plan")
async def generate_meal_plan(req: IngredientsRequest):
    """
    Takes a list of ingredients (without quantities) and generates a weekly meal plan
    """
    try:
        # Check if OpenAI client and API key are available
        if not client or not os.environ.get("OPENAI_API_KEY"):
            # Return fallback response with a friendly message
            fallback_response = {
                "meal_plan": [
                    {
                        "day": "Feature Unavailable",
                        "meals": [
                            {
                                "type": "Notice",
                                "name": "Meal Planning Unavailable",
                                "ingredients": ["OpenAI API Key (missing)"]
                            }
                        ]
                    }
                ],
                "shopping_list": ["The meal planning feature requires an OpenAI API key to work",
                                 "Please try the price comparison feature instead"]
            }
            return {"result": json.dumps(fallback_response)}
        
        # Join the ingredients into a comma-separated list
        ingredient_list = ", ".join(req.ingredients)
        
        # Create prompt for ChatGPT
        prompt = f"""
        I have the following ingredients: {ingredient_list}.
        
        Please create a 5-day meal plan using these ingredients, along with common pantry staples.
        For each day, include breakfast, lunch, and dinner options.
        
        Format your response as a JSON object with this structure:
        {{
          "meal_plan": [
            {{
              "day": "Monday",
              "meals": [
                {{
                  "type": "Breakfast",
                  "name": "Meal name",
                  "ingredients": ["Ingredient 1", "Ingredient 2"]
                }},
                {{
                  "type": "Lunch",
                  "name": "Meal name",
                  "ingredients": ["Ingredient 1", "Ingredient 2"]
                }},
                {{
                  "type": "Dinner",
                  "name": "Meal name",
                  "ingredients": ["Ingredient 1", "Ingredient 2"]
                }}
              ]
            }}
          ],
          "shopping_list": ["Additional item 1", "Additional item 2"]
        }}
        """
        
        # Call OpenAI API
        response = client.chat.completions.create(
            model="gpt-4o", # the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
            messages=[
                {"role": "system", "content": "You are a helpful meal planning assistant that creates practical meal plans based on available ingredients."},
                {"role": "user", "content": prompt}
            ],
            response_format={"type": "json_object"}
        )
        
        # Extract the response
        result = response.choices[0].message.content
        
        # Return the response
        return {"result": result}
        
    except Exception as e:
        print(f"Error in OpenAI API call: {str(e)}")
        fallback_response = {
            "meal_plan": [
                {
                    "day": "Error",
                    "meals": [
                        {
                            "type": "Error",
                            "name": f"Error: {str(e)}",
                            "ingredients": ["Error occurred during meal plan generation"]
                        }
                    ]
                }
            ],
            "shopping_list": ["The meal planning feature encountered an error", 
                             "Please try the price comparison feature instead"]
        }
        return {"result": json.dumps(fallback_response)}