# server/combined_app.py
from pathlib import Path
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.responses import RedirectResponse

# Import the existing FastAPI API app
from server.new_api import app as api_app  # adjust if your API entrypoint differs

app = FastAPI()

# Health for deployment checks
@app.get("/health")
def health():
    return {"status": "ok"}

# Use Vite outDir from vite.config.ts: dist/public
STATIC_DIR = (Path(__file__).resolve().parents[1] / "dist" / "public").resolve()

# Log if index.html is missing (don’t crash)
if not (STATIC_DIR / "index.html").exists():
    print(f"⚠️  dist/public/index.html not found at {STATIC_DIR}")

# Mount API first so /api takes precedence
app.mount("/api", api_app)

# Serve the SPA at root
app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")

# Explicit redirect for convenience (StaticFiles with html=True already handles this)
@app.get("/")
def root():
    return RedirectResponse(url="/index.html")

