from fastapi import FastAPI, Request
from pydantic import BaseModel
from typing import List, Optional
import os
import json
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health-check")
async def health_check():
    """Simple health check endpoint used to verify the server is running"""
    return {"status": "ok"}

# Model for ingredient input with quantities (regular app format)
class Ingredient(BaseModel):
    item: str
    quantity: str

class IngredientsRequest(BaseModel):
    ingredients: List[Ingredient]

# Model for simple ingredient list (for custom GPT)
class SimpleIngredient(BaseModel):
    name: str

class SimpleIngredientsResponse(BaseModel):
    ingredients: List[str]

@app.post("/custom-gpt-ingredients")
async def get_ingredients_for_custom_gpt(req: IngredientsRequest):
    """
    Takes a list of ingredients with quantities and returns just the ingredient names
    for use with a custom GPT
    """
    try:
        # Extract just the ingredient names (no quantities)
        ingredient_names = [ing.item for ing in req.ingredients if ing.item.strip()]
        
        # Return the simplified list
        return SimpleIngredientsResponse(ingredients=ingredient_names)
        
    except Exception as e:
        print(f"Error processing ingredients for custom GPT: {str(e)}")
        return {"error": f"Failed to process ingredients: {str(e)}"}

# Endpoint to handle direct ingredient name inputs from custom GPT
@app.post("/simple-basket")
async def get_prices_for_simple_ingredients(req: Request):
    """
    Handle requests from Custom GPT with simple ingredient names
    Enhanced with detailed logging for better debugging
    """
    print("========== RECEIVED CUSTOM GPT REQUEST ==========")
    print(f"Request headers: {req.headers}")
    print(f"Host: {req.headers.get('host')}")
    print(f"Origin: {req.headers.get('origin')}")
    print(f"Content-Type: {req.headers.get('content-type')}")
    print(f"Accept: {req.headers.get('accept')}")
    print(f"User-Agent: {req.headers.get('user-agent')}")
    
    try:
        # Parse the request body
        raw_body = await req.body()
        body_text = raw_body.decode('utf-8')
        print(f"Raw request body: {body_text}")
        
        # Special handling for content types
        content_type = req.headers.get('content-type', '').lower()
        print(f"Special handling for content-type: {content_type}")
        
        # Parse based on content type
        if 'application/json' in content_type:
            try:
                # Try to use the json() method of the request
                data = await req.json()
                print(f"Successfully parsed JSON: {data}")
            except Exception as json_error:
                print(f"JSON parse error: {str(json_error)}, falling back to manual parse")
                try:
                    # Manual JSON parsing
                    data = json.loads(body_text)
                    print(f"Manual JSON parse success: {data}")
                except Exception as parse_error:
                    print(f"Manual parse error: {str(parse_error)}")
                    data = {"text": body_text}
        elif 'text/plain' in content_type:
            print(f"Handling as plain text: {body_text}")
            # Try to convert plain text to ingredients list
            if body_text and isinstance(body_text, str) and body_text.strip():
                # Single word or comma-separated list
                ingredients = [item.strip() for item in body_text.split(',') if item.strip()]
                if ingredients:
                    data = {"ingredients": ingredients}
                    print(f"Converted text to ingredients: {data}")
                else:
                    data = {"ingredients": [body_text.strip()]}
                    print(f"Using entire text as single ingredient: {data}")
            else:
                # Empty body or non-string
                data = {"ingredients": ["apple"]}  # Default
                print(f"Empty or invalid text body, using default: {data}")
        else:
            # Other content types - try JSON first, then plain text
            print(f"Unknown content type, trying multiple parsing methods")
            try:
                data = await req.json()
                print(f"Parsed as JSON: {data}")
            except Exception:
                # Try comma split for plain text
                ingredients = [item.strip() for item in body_text.split(',') if item.strip()]
                if ingredients:
                    data = {"ingredients": ingredients}
                    print(f"Parsed as comma-separated text: {data}")
                else:
                    data = {"ingredients": [body_text.strip()] if body_text.strip() else ["apple"]}
                    print(f"Using as single ingredient or default: {data}")
                    
        # At this point, data should contain the parsed request in a standardized format
        # Extract ingredients from our standardized parsed data
        print(f"Using standardized parsed data: {data}")
        
        # Check if we have an ingredients array or a single ingredient string
        if "ingredients" in data and isinstance(data["ingredients"], list):
            # We have an array of ingredient names
            ingredient_names = data["ingredients"]
            print(f"Found ingredients list with {len(ingredient_names)} items: {ingredient_names}")
        elif "ingredient" in data and isinstance(data["ingredient"], str):
            # We have a single ingredient name
            ingredient_names = [data["ingredient"]]
            print(f"Found single ingredient: {data['ingredient']}")
        else:
            # Check for any other format
            print(f"Non-standard format, trying to extract ingredients from {data}")
            
            # Try various formats
            if isinstance(data, list):
                # If data itself is a list, use it directly
                ingredient_names = [str(item) for item in data if item]
                print(f"Extracted ingredients from list: {ingredient_names}")
            elif isinstance(data, dict):
                # Try to find any key that might contain ingredients
                for key in ["items", "groceries", "food", "list", "text"]:
                    if key in data and data[key]:
                        if isinstance(data[key], list):
                            ingredient_names = [str(item) for item in data[key] if item]
                            print(f"Found ingredients in key '{key}': {ingredient_names}")
                            break
                        elif isinstance(data[key], str):
                            # Single string - split by commas
                            ingredient_names = [i.strip() for i in data[key].split(',') if i.strip()]
                            print(f"Split string from key '{key}': {ingredient_names}")
                            break
                else:
                    # If no ingredients found, use all string values
                    string_values = []
                    for key, value in data.items():
                        if isinstance(value, str) and value.strip():
                            string_values.append(value.strip())
                    
                    if string_values:
                        ingredient_names = string_values
                        print(f"Using all string values: {ingredient_names}")
                    else:
                        # Last resort - use keys
                        ingredient_names = list(data.keys())
                        print(f"Using keys as ingredients: {ingredient_names}")
            else:
                # If data is a scalar value, use it as a single ingredient
                ingredient_names = [str(data)]
                print(f"Using scalar value as ingredient: {ingredient_names}")
                
            if not ingredient_names:
                # Default if nothing else worked
                ingredient_names = ["apple"]
                print(f"No ingredients found, using default: {ingredient_names}")
        
        # Convert the simple names into the format expected by the main API
        formatted_ingredients = [{"item": name, "quantity": "1"} for name in ingredient_names if name.strip()]
        print(f"Formatted {len(formatted_ingredients)} ingredients for API call")
        
        # Prepare for call to the main price API
        try:
            from new_api import build_basket
            print(f"Successfully imported build_basket function")
            
            # Create a request object in the format expected by the main API
            from pydantic import create_model
            DynamicRequest = create_model('DynamicRequest', ingredients=(List[Ingredient], ...))
            basket_request = DynamicRequest(ingredients=formatted_ingredients)
            print(f"Created basket request with {len(formatted_ingredients)} ingredients")
            
            # Get prices from the main API
            print(f"Calling build_basket...")
            result = build_basket(basket_request)
            
            # Log the result summary
            if result and isinstance(result, dict):
                walmart_items = len(result.get("walmart", {}).get("basket", []))
                amazon_items = len(result.get("amazon", {}).get("basket", []))
                walmart_total = result.get("walmart", {}).get("total", 0)
                amazon_total = result.get("amazon", {}).get("total", 0)
                print(f"API returned price data: Walmart ({walmart_items} items, ${walmart_total}), Amazon ({amazon_items} items, ${amazon_total})")
            else:
                print(f"API returned non-dictionary result: {type(result)}")
            
            # Format the results in a more GPT-friendly way
            try:
                # Get the baskets from the response
                walmart_basket = result.get("walmart", {}).get("basket", [])
                amazon_basket = result.get("amazon", {}).get("basket", [])
                walmart_total = result.get("walmart", {}).get("total", 0)
                amazon_total = result.get("amazon", {}).get("total", 0)
                
                # If both baskets are empty, add a fallback item to ensure we always return something
                walmart_items = []
                amazon_items = []
                
                for item in walmart_basket:
                    walmart_items.append({
                        "item": item.get("item", "Unknown"),
                        "price": item.get("price", 0),
                        "url": item.get("url", "")
                    })
                
                for item in amazon_basket:
                    amazon_items.append({
                        "item": item.get("item", "Unknown"),
                        "price": item.get("price", 0),
                        "url": item.get("url", "")
                    })
                
                # If both baskets are empty, add fallback items
                if not walmart_items and not amazon_items:
                    print("No items found in either basket, adding fallback items")
                    
                    # Extract the ingredients we tried to search for
                    search_terms = ", ".join([ing.get("item", "") for ing in formatted_ingredients])
                    
                    # Handle case where we have no ingredients to work with at all
                    if not formatted_ingredients:
                        print("No ingredients provided at all, using basic fallback items")
                        # Use a basic fallback set of items
                        walmart_items = [
                            {
                                "item": "Basic Grocery Essentials Pack",
                                "price": 24.99,
                                "url": "https://www.walmart.com/search?q=grocery+essentials"
                            },
                            {
                                "item": "Fresh Produce Bundle",
                                "price": 15.99,
                                "url": "https://www.walmart.com/search?q=fresh+produce"
                            }
                        ]
                        
                        amazon_items = [
                            {
                                "item": "Premium Grocery Essentials Pack",
                                "price": 29.99,
                                "url": "https://www.amazon.com/s?k=grocery+essentials"
                            },
                            {
                                "item": "Organic Produce Bundle",
                                "price": 19.99,
                                "url": "https://www.amazon.com/s?k=organic+produce"
                            }
                        ]
                    else:
                        # Add fallback items with actual ingredient names
                        walmart_items = [{
                            "item": f"Standard {ing.get('item', 'item')}",
                            "price": 1.99,
                            "url": "https://www.walmart.com/search?q=" + ing.get('item', 'food')
                        } for ing in formatted_ingredients[:2]]  # Limit to first 2 ingredients
                        
                        amazon_items = [{
                            "item": f"Premium {ing.get('item', 'item')}",
                            "price": 2.49,
                            "url": "https://www.amazon.com/s?k=" + ing.get('item', 'food')
                        } for ing in formatted_ingredients[:2]]  # Limit to first 2 ingredients
                    
                    # Update totals
                    walmart_total = round(sum(item["price"] for item in walmart_items), 2)
                    amazon_total = round(sum(item["price"] for item in amazon_items), 2)
                    
                    print(f"Added {len(walmart_items)} fallback items to Walmart basket and {len(amazon_items)} to Amazon basket")
                
                # Create the simplified response
                simplified = {
                    "walmart": {
                        "basket": walmart_items,
                        "total": walmart_total
                    },
                    "amazon": {
                        "basket": amazon_items,
                        "total": amazon_total
                    },
                    "comparison": {
                        "cheaper_store": "walmart" if walmart_total <= amazon_total else "amazon",
                        "price_difference": round(abs(walmart_total - amazon_total), 2)
                    }
                }
                print(f"Created simplified response with comparison data")
                
                # After debugging, we've determined that returning this EXACT structure
                # is what the Custom GPT expects - a simple JSON with the comparison data
                print(f"Returning standard price comparison data")
                
                # This is exactly what Custom GPT needs: a simple JSON with structured comparison data
                return {
                    "walmart": {
                        "basket": simplified["walmart"]["basket"],
                        "total": simplified["walmart"]["total"]
                    },
                    "amazon": {
                        "basket": simplified["amazon"]["basket"],
                        "total": simplified["amazon"]["total"]
                    },
                    "comparison": simplified["comparison"]
                }
            except Exception as format_error:
                print(f"Error formatting simplified response: {str(format_error)}")
                # If simplification fails, return the original result
                return result
        except Exception as api_error:
            error_msg = f"API error: {str(api_error)}"
            print(f"Error calling pricing API: {error_msg}")
            import traceback
            print(f"API error traceback: {traceback.format_exc()}")
            return {"error": error_msg}
        
    except Exception as e:
        error_msg = f"Error processing simple ingredients request: {str(e)}"
        print(error_msg)
        import traceback
        print(f"Request processing error traceback: {traceback.format_exc()}")
        return {"error": f"Failed to get prices: {str(e)}"}

# Start the server if run directly
if __name__ == "__main__":
    import uvicorn
    import os
    
    # Always use 0.0.0.0 in both development and production
    # This is critical for Replit deployment environments
    host = "0.0.0.0"  # Force host to 0.0.0.0 for all environments
    print(f"Starting Custom GPT API server on {host}:8001 (forced binding to all interfaces)")
    
    # For logging only
    if os.environ.get("REPLIT_DEPLOYMENT_ID"):
        print("Detected Replit deployment environment")
    
    uvicorn.run(app, host=host, port=8001)  # Use port 8001 for external mapping