import { Switch, Route, Link } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import RecipeToBasket from "@/pages/recipe-to-basket";
import WalmartLinkTest from "@/components/walmart-link-test";
import Footer from "@/components/footer";
import ReplitBadgeRemover from "@/components/replit-badge-remover";
import { MobileInstallPrompt, MobileOptimizations } from "@/components/mobile-enhancements";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/recipe" component={RecipeToBasket} />
      <Route path="/walmart-test" component={WalmartLinkTest} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex flex-col min-h-screen">
        <div className="flex-grow">
          <Router />
        </div>
        <Footer />
      </div>
      <Toaster />
      <ReplitBadgeRemover />
      <MobileInstallPrompt />
      <MobileOptimizations />
    </QueryClientProvider>
  );
}

export default App;
