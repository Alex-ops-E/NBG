import { useState } from "react";
import IngredientForm from "@/components/ingredient-form";
import ComparisonResults from "@/components/comparison-results";
import LoadingIndicator from "@/components/loading-indicator";
import NoResults from "@/components/no-results";
import ErrorState from "@/components/error-state";
import { useToast } from "@/hooks/use-toast";
import { compareIngredients } from "@/lib/api";
import Navigation from "@/components/navigation";

type ComparisonData = {
  walmart: {
    basket: BasketItem[];
    total: number;
  };
  amazon: {
    basket: BasketItem[];
    total: number;
  };
};

export type BasketItem = {
  item: string;
  quantity: string;
  price: number;
  url: string;
  size?: string; // Optional size/weight of the product (e.g., "16 oz", "1 gallon")
  pricePerUnit?: string | { price: number; unit: string }; // Optional pre-calculated price per unit (can be string or object)
};

export type Ingredient = {
  item: string;
  quantity: string;
};

export default function Home() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [comparisonData, setComparisonData] = useState<ComparisonData | null>(null);
  const [ingredientList, setIngredientList] = useState<Ingredient[]>([
    { item: "", quantity: "" }
  ]);
  const { toast } = useToast();

  const handleCompare = async (ingredients: Ingredient[]) => {
    // Filter out empty ingredients
    const validIngredients = ingredients.filter(ing => ing.item.trim() !== "");
    
    if (validIngredients.length === 0) {
      toast({
        title: "No ingredients",
        description: "Please add at least one ingredient to compare",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const data = await compareIngredients(validIngredients);
      setComparisonData(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred");
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed to compare prices",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4 py-4">
        <Navigation />
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <IngredientForm 
          ingredients={ingredientList} 
          setIngredients={setIngredientList} 
          onSubmit={handleCompare} 
        />
        
        {loading && <LoadingIndicator />}
        
        {!loading && error && <ErrorState error={error} onRetry={() => handleCompare(ingredientList)} />}
        
        {!loading && !error && comparisonData && (
          <ComparisonResults data={comparisonData} />
        )}
        
        {!loading && !error && !comparisonData && <NoResults />}
      </main>

      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="md:flex md:items-center md:justify-between">
            <div className="flex justify-center md:order-2 space-x-6">
              <a href="#" className="text-gray-400 hover:text-gray-500">
                <i className="fab fa-github text-lg"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-gray-500">
                <i className="fab fa-twitter text-lg"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-gray-500">
                <i className="fas fa-envelope text-lg"></i>
              </a>
            </div>
            <div className="mt-8 md:mt-0 md:order-1">
              <p className="text-center text-base text-gray-400">
                &copy; {new Date().getFullYear()} Grocery Price Comparison Tool. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
