import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ChefHat, ShoppingCart, Loader2, ArrowRight, List, Sparkles, Clock, Users, ChefHatIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import LoadingIndicator from "@/components/loading-indicator";
import ComparisonResults from "@/components/comparison-results";
import ErrorState from "@/components/error-state";
import NoResults from "@/components/no-results";
import Navigation from "@/components/navigation";

interface BasketItem {
  item: string;
  quantity: string;
  price: number;
  url: string;
  size?: string;
  pricePerUnit?: string | { price: number; unit: string };
  link?: string;
  image?: string;
}

interface ComparisonData {
  walmart: {
    basket: BasketItem[];
    total: number;
  };
  amazon: {
    basket: BasketItem[];
    total: number;
  };
}

interface Recipe {
  title: string;
  description: string;
  servings: number;
  prep_time: string;
  cook_time: string;
  difficulty: string;
  ingredients: string[];
  instructions: string[];
  tips: string[];
}

export default function RecipeToBasket() {
  const [mode, setMode] = useState<"generate">("generate");
  const [recipe, setRecipe] = useState("");
  const [generatedRecipe, setGeneratedRecipe] = useState<Recipe | null>(null);
  const [extractedIngredients, setExtractedIngredients] = useState<string[]>([]);
  const [comparisonData, setComparisonData] = useState<ComparisonData | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isComparing, setIsComparing] = useState(false);
  const [error, setError] = useState("");
  const [step, setStep] = useState<"input" | "recipe" | "ingredients" | "results">("input");

  // Recipe generation form state
  const [preferences, setPreferences] = useState("");
  const [servings, setServings] = useState(2);
  const [cuisine, setCuisine] = useState("any");
  const [dietary, setDietary] = useState<string[]>([]);

  const { toast } = useToast();

  const handleGenerateRecipe = async () => {
    if (!preferences.trim()) {
      toast({
        title: "Preferences Required",
        description: "Please describe what kind of recipe you'd like to generate.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    setError("");

    try {
      const response = await fetch("/api/ai-generate-recipe", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          preferences: preferences.trim(),
          servings,
          dietary,
          cuisine,
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to generate recipe: ${response.status}`);
      }

      const data = await response.json();

      if (data.success && data.recipe) {
        setGeneratedRecipe(data.recipe);
        setExtractedIngredients(data.recipe.ingredients || []);
        setStep("recipe");
        toast({
          title: "Recipe Generated",
          description: `Created "${data.recipe.title}" with ${data.recipe.ingredients?.length || 0} ingredients.`,
        });
      } else {
        throw new Error("No recipe could be generated from your preferences");
      }
    } catch (error) {
      console.error("Error generating recipe:", error);
      const errorMessage = error instanceof Error ? error.message : "Unknown error occurred";
      
      // Check if it's a network error or server error
      if (errorMessage.includes('fetch') || errorMessage.includes('NetworkError')) {
        setError("Network connection issue. Please check your internet connection and try again.");
      } else if (errorMessage.includes('timeout')) {
        setError("Request timed out. Please try again or use simpler preferences.");
      } else {
        setError("Failed to generate recipe. Please try again with different preferences or check back later.");
      }
      
      toast({
        title: "Generation Failed",
        description: "Could not generate recipe. Please try a simpler request or try again later.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleExtractIngredients = async () => {
    if (!recipe.trim()) {
      toast({
        title: "Recipe Required",
        description: "Please paste a recipe to extract ingredients from.",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    setError("");

    try {
      // Always use OpenAI smart extraction for reliable results in both dev and deployment
      const response = await fetch("/api/ai-extract-ingredients", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          recipe: recipe.trim(),
        }),
      });

      if (!response.ok) {
        throw new Error(`Failed to extract ingredients: ${response.status}`);
      }

      const data = await response.json();

      if (data.success && data.ingredients && data.ingredients.length > 0) {
        setExtractedIngredients(data.ingredients);
        setStep("ingredients");
        toast({
          title: "Ingredients Extracted",
          description: `Found ${data.ingredients.length} ingredients in your recipe.`,
        });
      } else {
        throw new Error("No ingredients could be extracted from the recipe");
      }
    } catch (error) {
      console.error("Error extracting ingredients:", error);
      setError("Failed to extract ingredients from recipe. Please try again or manually list the ingredients.");
      toast({
        title: "Extraction Failed",
        description: "Could not extract ingredients. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCompareBasket = async () => {
    if (extractedIngredients.length === 0) {
      toast({
        title: "No Ingredients",
        description: "Please extract ingredients first before comparing prices.",
        variant: "destructive",
      });
      return;
    }

    setIsComparing(true);
    setError("");

    try {
      const response = await fetch("/api/basket", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ingredients: extractedIngredients,
        }),
      });

      if (!response.ok) {
        // Handle deployment mode gracefully
        if (response.status === 503) {
          const errorData = await response.json();
          if (errorData.deployment_mode) {
            setError("Price comparison is temporarily unavailable in deployment mode. The recipe generation feature works fully - please check back later for price comparisons.");
            toast({
              title: "Service Temporarily Unavailable",
              description: "Price comparison will be available soon. Recipe generation is working perfectly!",
              variant: "destructive",
            });
            return;
          }
        }
        throw new Error(`Failed to compare prices: ${response.status}`);
      }

      const data = await response.json();
      setComparisonData(data);
      setStep("results");
      toast({
        title: "Price Comparison Complete",
        description: "Successfully compared prices across retailers.",
      });
    } catch (error) {
      console.error("Error comparing prices:", error);
      setError("Failed to compare prices. Please check your connection and try again.");
      toast({
        title: "Comparison Failed",
        description: "Could not compare prices. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsComparing(false);
    }
  };

  const handleStartOver = () => {
    setRecipe("");
    setGeneratedRecipe(null);
    setExtractedIngredients([]);
    setComparisonData(null);
    setError("");
    setPreferences("");
    setServings(2);
    setCuisine("any");
    setDietary([]);
    setStep("input");
  };

  const toggleDietaryRestriction = (restriction: string) => {
    setDietary(prev =>
      prev.includes(restriction)
        ? prev.filter(d => d !== restriction)
        : [...prev, restriction]
    );
  };

  const proceedToIngredients = () => {
    if (generatedRecipe && generatedRecipe.ingredients) {
      setExtractedIngredients(generatedRecipe.ingredients);
      setStep("ingredients");
    }
  };

  const removeIngredient = (index: number) => {
    const updated = extractedIngredients.filter((_, i) => i !== index);
    setExtractedIngredients(updated);
  };

  const editIngredient = (index: number, newValue: string) => {
    const updated = [...extractedIngredients];
    updated[index] = newValue.trim();
    setExtractedIngredients(updated);
  };

  // Recipe display component
  if (step === "recipe" && generatedRecipe) {
    return (
      <div className="bg-gray-50 min-h-screen">
        <div className="container mx-auto px-4 py-4">
          <Navigation />
        </div>
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <ChefHat className="w-8 h-8 text-blue-600" />
              <h1 className="text-2xl font-bold">Generated Recipe</h1>
            </div>
            <Button onClick={handleStartOver} variant="outline">
              Generate New Recipe
            </Button>
          </div>

          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl">{generatedRecipe.title}</CardTitle>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Users className="w-4 h-4" />
                    <span>{generatedRecipe.servings} servings</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>{generatedRecipe.prep_time} + {generatedRecipe.cook_time}</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 mt-2">{generatedRecipe.description}</p>
              <div className="flex items-center justify-between mt-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  generatedRecipe.difficulty === 'Easy' ? 'bg-green-100 text-green-800' :
                  generatedRecipe.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {generatedRecipe.difficulty}
                </span>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold text-lg mb-3 flex items-center space-x-2">
                  <List className="w-5 h-5" />
                  <span>Ingredients ({generatedRecipe.ingredients.length})</span>
                </h3>
                <div className="grid gap-2">
                  {generatedRecipe.ingredients.map((ingredient, index) => (
                    <div key={index} className="flex items-center space-x-3 p-2 bg-gray-50 rounded">
                      <span className="font-mono text-sm text-gray-500 min-w-6">{index + 1}.</span>
                      <span className="flex-1">{ingredient}</span>
                    </div>
                  ))}
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="font-semibold text-lg mb-3">Instructions</h3>
                <div className="space-y-3">
                  {generatedRecipe.instructions.map((instruction, index) => (
                    <div key={index} className="flex space-x-3">
                      <span className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-medium">
                        {index + 1}
                      </span>
                      <p className="flex-1 text-gray-700">{instruction}</p>
                    </div>
                  ))}
                </div>
              </div>

              {generatedRecipe.tips && generatedRecipe.tips.length > 0 && (
                <>
                  <Separator />
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Chef's Tips</h3>
                    <div className="space-y-2">
                      {generatedRecipe.tips.map((tip, index) => (
                        <div key={index} className="flex items-start space-x-2 p-3 bg-blue-50 rounded-lg">
                          <ChefHatIcon className="w-4 h-4 text-blue-600 mt-0.5" />
                          <p className="text-blue-800 text-sm">{tip}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}

              <Separator />

              <div className="flex justify-center">
                <Button onClick={proceedToIngredients} size="lg" className="mobile-touch-target">
                  <ShoppingCart className="w-4 h-4 mr-2" />
                  Shop for Ingredients
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (step === "results" && comparisonData) {
    return (
      <div className="bg-gray-50 min-h-screen">
        <div className="container mx-auto px-4 py-4">
          <Navigation />
        </div>
        <div className="container mx-auto px-4 py-8 max-w-6xl">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <ShoppingCart className="w-8 h-8 text-blue-600" />
              <h1 className="text-2xl font-bold">Recipe Shopping Results</h1>
            </div>
            <Button onClick={handleStartOver} variant="outline">
              New Recipe
            </Button>
          </div>

        <div className="mb-6">
          <p className="text-gray-600">Price comparison for {extractedIngredients.length} ingredients from your recipe</p>
        </div>

          <ComparisonResults data={comparisonData} />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="container mx-auto px-4 py-4">
        <Navigation />
      </div>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center space-x-3 mb-4">
          <div className="relative">
            <ChefHat className="w-10 h-10 text-blue-600" />
            <Sparkles className="w-4 h-4 text-yellow-500 absolute -top-1 -right-1" />
          </div>
          <h1 className="text-3xl font-bold">AI Recipe Generator & Shopping Assistant</h1>
        </div>
        <p className="text-gray-600">
          Generate custom recipes with AI and get shopping price comparisons
        </p>
      </div>

      

      {error && <ErrorState error={error} onRetry={() => setError("")} />}

      {step === "input" && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-yellow-500" />
              <span>Generate Custom Recipe</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="text-sm font-medium mb-2 block">What would you like to cook?</label>
              <Textarea
                placeholder="Describe what you're craving... 

Examples:
• A healthy vegetarian pasta dish for dinner
• Quick 30-minute chicken meal with vegetables  
• Comfort food dessert with chocolate
• Spicy Asian-inspired stir fry"
                value={preferences}
                onChange={(e) => setPreferences(e.target.value)}
                className="min-h-32 text-base"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Servings</label>
                <Select value={servings.toString()} onValueChange={(value) => setServings(Number(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select servings" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 person</SelectItem>
                    <SelectItem value="2">2 people</SelectItem>
                    <SelectItem value="4">4 people</SelectItem>
                    <SelectItem value="6">6 people</SelectItem>
                    <SelectItem value="8">8 people</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">Cuisine Style (Optional)</label>
                <Select value={cuisine} onValueChange={setCuisine}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any cuisine" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any cuisine</SelectItem>
                    <SelectItem value="Italian">Italian</SelectItem>
                    <SelectItem value="Mexican">Mexican</SelectItem>
                    <SelectItem value="Asian">Asian</SelectItem>
                    <SelectItem value="Mediterranean">Mediterranean</SelectItem>
                    <SelectItem value="American">American</SelectItem>
                    <SelectItem value="Indian">Indian</SelectItem>
                    <SelectItem value="French">French</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Dietary Preferences (Optional)</label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {["Vegetarian", "Vegan", "Gluten-Free", "Dairy-Free", "Keto", "Low-Carb"].map((diet) => (
                  <div key={diet} className="flex items-center space-x-2">
                    <Checkbox 
                      id={diet}
                      checked={dietary.includes(diet)}
                      onCheckedChange={() => toggleDietaryRestriction(diet)}
                    />
                    <label htmlFor={diet} className="text-sm cursor-pointer">{diet}</label>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-center">
              <Button 
                onClick={handleGenerateRecipe}
                disabled={isGenerating || !preferences.trim()}
                size="lg"
                className="mobile-touch-target"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Generating Recipe...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Recipe
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      

      {step === "ingredients" && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <List className="w-5 h-5" />
              <span>Extracted Ingredients ({extractedIngredients.length})</span>
            </CardTitle>
            <p className="text-sm text-gray-600">Review and edit the ingredients before comparing prices</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3">
              {extractedIngredients.map((ingredient, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <span className="font-mono text-sm text-gray-500 min-w-6">{index + 1}.</span>
                  <input
                    type="text"
                    value={ingredient}
                    onChange={(e) => editIngredient(index, e.target.value)}
                    className="flex-1 bg-transparent border-none outline-none text-base"
                  />
                  <Button
                    onClick={() => removeIngredient(index)}
                    variant="ghost"
                    size="sm"
                    className="text-red-500 hover:text-red-700"
                  >
                    Remove
                  </Button>
                </div>
              ))}
            </div>

            <Separator />

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button 
                onClick={handleStartOver}
                variant="outline"
                className="mobile-touch-target mobile-button-full"
              >
                Start Over
              </Button>
              <Button 
                onClick={handleCompareBasket}
                disabled={isComparing || extractedIngredients.length === 0}
                size="lg"
                className="mobile-touch-target mobile-button-full"
              >
                {isComparing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Comparing Prices...
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Compare Prices
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {(isProcessing || isComparing || isGenerating) && <LoadingIndicator />}
      </div>
    </div>
  );
}