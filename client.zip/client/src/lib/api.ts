import { Ingredient } from "@/pages/home";
import { apiRequest } from "./queryClient";

export async function compareIngredients(ingredients: Ingredient[]) {
  const response = await apiRequest("POST", "/api/basket", { ingredients });
  return await response.json();
}

// Generate recipe suggestions using ChatGPT (API only requires ingredient names, not quantities)
export async function generateRecipes(ingredients: Ingredient[]) {
  const response = await apiRequest("POST", "/api/generate-recipes", { ingredients });
  return await response.json();
}

// Generate meal plan using ChatGPT (API only requires ingredient names, not quantities)
export async function generateMealPlan(ingredients: Ingredient[]) {
  const response = await apiRequest("POST", "/api/meal-plan", { ingredients });
  return await response.json();
}
