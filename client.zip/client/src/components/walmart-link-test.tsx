import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

/**
 * A component to test different Walmart link formats
 */
export default function WalmartLinkTest() {
  const productId = "27935095"; // Foster Farms chicken breast

  const linkFormats = [
    {
      format: "Basic ID only",
      url: `https://www.walmart.com/ip/${productId}`,
      description: "Just the product ID with no product name"
    },
    {
      format: "With product name",
      url: `https://www.walmart.com/ip/Foster-Farms-Fresh-Natural-Chicken-Breast-Fillets/${productId}`,
      description: "Product name followed by ID"
    },
    {
      format: "With numeric ID in middle",
      url: `https://www.walmart.com/ip/${productId}/Foster-Farms-Fresh-Natural-Chicken-Breast-Fillets`,
      description: "ID followed by product name"
    },
    {
      format: "Search query",
      url: `https://www.walmart.com/search?q=chicken+breast`,
      description: "Search query for the product"
    },
    {
      format: "Direct no IP path",
      url: `https://www.walmart.com/item/${productId}`,
      description: "Using item path instead of ip path"
    }
  ];

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Walmart Link Format Test</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4">
            <p className="text-gray-600 mb-4">
              Click each link format to see which one correctly redirects to the Walmart product page.
              Open links in a new tab to keep this test page open.
            </p>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Format
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Description
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Test Link
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {linkFormats.map((format, index) => (
                    <tr key={index}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{format.format}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-600">{format.description}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <a 
                          href={format.url} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-blue-600 hover:text-blue-800 underline"
                        >
                          {format.url}
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}