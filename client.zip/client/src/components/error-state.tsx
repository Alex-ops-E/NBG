import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ErrorStateProps {
  error: string;
  onRetry: () => void;
}

export default function ErrorState({ error, onRetry }: ErrorStateProps) {
  return (
    <Card className="bg-white shadow rounded-lg">
      <CardContent className="p-8 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 mb-4">
          <i className="fas fa-exclamation-triangle text-red-600 text-2xl"></i>
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">Error Fetching Results</h3>
        <p className="text-gray-500 mb-4">{error || "There was a problem comparing prices. Please try again later."}</p>
        <Button onClick={onRetry} className="inline-flex items-center">
          <i className="fas fa-redo-alt mr-2"></i>
          Try Again
        </Button>
      </CardContent>
    </Card>
  );
}
