import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { QrCode, Camera, X } from "lucide-react";

interface MobileBarcodeScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (barcode: string) => void;
}

export default function MobileBarcodeScanner({ isOpen, onClose, onScan }: MobileBarcodeScannerProps) {
  const [isScanning, setIsScanning] = useState(false);

  const simulateScan = () => {
    setIsScanning(true);
    
    // Simulate scanning delay
    setTimeout(() => {
      const sampleBarcodes = [
        { code: '012000001000', name: 'Coca-Cola 12-pack' },
        { code: '028400064002', name: 'Lay\'s Classic Chips' },
        { code: '030000310908', name: 'Oreo Original Cookies' },
        { code: '041220136967', name: 'Cheerios Cereal' },
        { code: '016000275263', name: 'Nature Valley Granola Bars' },
      ];
      
      const randomProduct = sampleBarcodes[Math.floor(Math.random() * sampleBarcodes.length)];
      onScan(randomProduct.name);
      setIsScanning(false);
      onClose();
    }, 2000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="w-5 h-5" />
            Barcode Scanner
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="flex flex-col items-center space-y-4">
            <div className="w-48 h-48 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center bg-gray-50">
              {isScanning ? (
                <div className="flex flex-col items-center space-y-2">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                  <p className="text-sm text-gray-600">Scanning...</p>
                </div>
              ) : (
                <div className="flex flex-col items-center space-y-2">
                  <Camera className="w-12 h-12 text-gray-400" />
                  <p className="text-sm text-gray-600">Camera preview</p>
                </div>
              )}
            </div>
            
            <p className="text-sm text-gray-600 text-center">
              Position the barcode within the frame to scan
            </p>
          </div>

          <div className="flex flex-col space-y-3">
            <Button 
              onClick={simulateScan} 
              disabled={isScanning}
              className="w-full"
              size="lg"
            >
              <QrCode className="w-4 h-4 mr-2" />
              {isScanning ? 'Scanning...' : 'Simulate Scan (Demo)'}
            </Button>
            
            <Button 
              variant="outline" 
              onClick={onClose}
              className="w-full"
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
          </div>

          <div className="text-xs text-gray-500 text-center">
            This is a demo scanner. In production, this would use your device's camera to scan real barcodes.
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}