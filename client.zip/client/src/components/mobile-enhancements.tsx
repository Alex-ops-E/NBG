import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Smartphone, Download, Share2 } from "lucide-react";

export function MobileInstallPrompt() {
  const [showPrompt, setShowPrompt] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    // Check if user is on mobile
    const isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    if (isMobile) {
      setShowPrompt(true);
    }

    // Listen for beforeinstallprompt event (PWA)
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowPrompt(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      
      if (outcome === 'accepted') {
        setDeferredPrompt(null);
        setShowPrompt(false);
      }
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Grocery Price Comparison',
          text: 'Compare grocery prices across Walmart and Amazon',
          url: window.location.href,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    }
  };

  if (!showPrompt) return null;

  return (
    <Card className="fixed bottom-4 left-4 right-4 z-50 shadow-lg md:hidden">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Smartphone className="w-6 h-6 text-blue-600" />
            <div>
              <p className="text-sm font-medium">Add to Home Screen</p>
              <p className="text-xs text-gray-600">Install for better mobile experience</p>
            </div>
          </div>
          <div className="flex space-x-2">
            {navigator.share && (
              <Button size="sm" variant="outline" onClick={handleShare}>
                <Share2 className="w-4 h-4" />
              </Button>
            )}
            {deferredPrompt && (
              <Button size="sm" onClick={handleInstall}>
                <Download className="w-4 h-4 mr-1" />
                Install
              </Button>
            )}
            <Button size="sm" variant="ghost" onClick={() => setShowPrompt(false)}>
              ×
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function MobileOptimizations() {
  useEffect(() => {
    // Add mobile viewport meta tag if not present
    if (!document.querySelector('meta[name="viewport"]')) {
      const viewport = document.createElement('meta');
      viewport.name = 'viewport';
      viewport.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
      document.head.appendChild(viewport);
    }

    // Add PWA meta tags
    const themeColor = document.createElement('meta');
    themeColor.name = 'theme-color';
    themeColor.content = '#2563eb';
    document.head.appendChild(themeColor);

    const appleCapable = document.createElement('meta');
    appleCapable.name = 'apple-mobile-web-app-capable';
    appleCapable.content = 'yes';
    document.head.appendChild(appleCapable);

    const appleTitle = document.createElement('meta');
    appleTitle.name = 'apple-mobile-web-app-title';
    appleTitle.content = 'Price Compare';
    document.head.appendChild(appleTitle);

    return () => {
      // Cleanup if needed
    };
  }, []);

  return null;
}