import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Home, ChefHat } from "lucide-react";

export default function Navigation() {
  const [location] = useLocation();
  
  return (
    <Card className="sticky top-4 z-40 shadow-lg">
      <CardContent className="p-3">
        <nav className="flex items-center justify-center space-x-2 sm:space-x-4">
          <Link href="/">
            <Button 
              variant={location === "/" ? "default" : "outline"}
              size="sm"
              className="mobile-touch-target flex items-center space-x-2"
            >
              <Home className="w-4 h-4" />
              <span className="hidden sm:inline">Compare Prices</span>
              <span className="sm:hidden">Prices</span>
            </Button>
          </Link>
          
          <Link href="/recipe">
            <Button 
              variant={location === "/recipe" ? "default" : "outline"}
              size="sm"
              className="mobile-touch-target flex items-center space-x-2"
            >
              <ChefHat className="w-4 h-4" />
              <span className="hidden sm:inline">Recipe to Basket</span>
              <span className="sm:hidden">Recipe</span>
            </Button>
          </Link>
        </nav>
      </CardContent>
    </Card>
  );
}