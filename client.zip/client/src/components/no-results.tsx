import { Card, CardContent } from "@/components/ui/card";

export default function NoResults() {
  return (
    <Card className="bg-white shadow rounded-lg">
      <CardContent className="p-8 text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gray-100 mb-4">
          <i className="fas fa-search text-gray-400 text-2xl"></i>
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">No Results Yet</h3>
        <p className="text-gray-500 mb-4">Enter your ingredients and hit "Compare Prices" to see the comparison.</p>
      </CardContent>
    </Card>
  );
}
