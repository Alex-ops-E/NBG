import React from 'react';
import { Separator } from "@/components/ui/separator";

export default function Footer() {
  return (
    <footer className="w-full mt-12 py-6 px-4 border-t bg-background/80 backdrop-blur-sm">
      <div className="container mx-auto max-w-6xl text-sm text-muted-foreground">
        <div className="mb-4">
          <h3 className="text-md font-medium text-foreground mb-2">Disclaimer</h3>
          <p>
            Nutrilab is an experimental tool that helps users compare prices across retailers. 
            We are not affiliated with or endorsed by Walmart or Amazon. 
            Prices and availability may vary and are provided via third-party APIs.
          </p>
        </div>
        
        <Separator className="my-4" />
        
        <div>
          <h3 className="text-md font-medium text-foreground mb-2">Terms of Use</h3>
          <ul className="list-disc pl-5 space-y-1">
            <li>This tool is provided as-is and for informational purposes only.</li>
            <li>Do not rely on price or availability data for any purchasing decisions.</li>
            <li>Tool uses third-party APIs for demonstration purposes only. No guarantee of data accuracy or availability.</li>
          </ul>
        </div>
        
        <div className="mt-6 text-xs">
          © {new Date().getFullYear()} Nutrilab. All rights reserved.
        </div>
      </div>
    </footer>
  );
}