import { Card, CardContent } from "@/components/ui/card";

export default function LoadingIndicator() {
  return (
    <Card className="bg-white shadow rounded-lg">
      <CardContent className="p-8 text-center">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
        <p className="mt-4 text-gray-700">Fetching prices from retailers...</p>
      </CardContent>
    </Card>
  );
}
