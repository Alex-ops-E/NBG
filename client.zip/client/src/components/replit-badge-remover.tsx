import { useEffect } from 'react';

/**
 * Component that removes Replit badge/banner
 * This is a React component that uses DOM manipulation to target and remove the Replit banner
 */
export default function ReplitBadgeRemover() {
  useEffect(() => {
    // Function to remove Replit banner elements
    function removeReplitElements() {
      const selectors = [
        'div[role="dialog"][aria-modal="true"]',
        'div[class*="style_replit-badge-container"]',
        'div[class*="replit-badge-container"]',
        'iframe[src*="replit.com"]',
        'div[class*="fixed"][class*="bottom-0"]',
        // Target specifically the badge shown in screenshot
        'div[class^="jsx-"][class*="fixed"] div[class^="jsx-"] span:first-child',
        // More generic selectors
        'div[role="dialog"] div[class*="fixed"]',
        'div[class*="fixed"][class*="bottom-0"] button'
      ];
      
      let found = false;
      
      selectors.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        if (elements.length > 0) {
          found = true;
          elements.forEach(el => {
            // Try to find the dialog parent
            let parent = el as HTMLElement;
            let attempts = 0;
            
            // Look up the DOM tree for dialog elements
            while (parent && attempts < 10) {
              if (
                parent.getAttribute('role') === 'dialog' || 
                parent.getAttribute('aria-modal') === 'true'
              ) {
                parent.style.display = 'none';
                parent.remove();
                return;
              }
              const parentEl = parent.parentElement;
              if (!parentEl) break;
              parent = parentEl;
              attempts++;
            }
            
            // If no dialog parent found, just hide this element
            (el as HTMLElement).style.display = 'none';
            if (el.parentElement) {
              el.remove();
            }
          });
        }
      });
      
      return found;
    }
    
    // Try immediately
    const initialRemoval = removeReplitElements();
    
    // Set up an interval to keep checking
    const interval = setInterval(() => {
      const found = removeReplitElements();
      // If we didn't find anything for a while, we can reduce the frequency
      if (!found && interval) {
        clearInterval(interval);
        // Check less frequently after a while
        setInterval(removeReplitElements, 5000);
      }
    }, 1000);
    
    // Clean up the interval when the component unmounts
    return () => {
      clearInterval(interval);
    };
  }, []);
  
  // This component doesn't render anything
  return null;
}