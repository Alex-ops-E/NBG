import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Trash2 } from "lucide-react";
import { Ingredient } from "@/pages/home";
import { useToast } from "@/hooks/use-toast";

interface IngredientFormProps {
  ingredients: Ingredient[];
  setIngredients: (ingredients: Ingredient[]) => void;
  onSubmit: (ingredients: Ingredient[]) => void;
}

export default function IngredientForm({ 
  ingredients, 
  setIngredients, 
  onSubmit 
}: IngredientFormProps) {
  const { toast } = useToast();
  
  const handleIngredientChange = (index: number, field: keyof Ingredient, value: string) => {
    const updatedIngredients = [...ingredients];
    updatedIngredients[index] = {
      ...updatedIngredients[index],
      [field]: value
    };
    setIngredients(updatedIngredients);
  };

  const addIngredient = () => {
    setIngredients([...ingredients, { item: "", quantity: "" }]);
  };

  const removeIngredient = (index: number) => {
    const updatedIngredients = [...ingredients];
    updatedIngredients.splice(index, 1);
    setIngredients(updatedIngredients.length ? updatedIngredients : [{ item: "", quantity: "" }]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(ingredients);
  };



  return (
    <Card className="bg-white shadow rounded-lg mb-6">
      <CardContent className="p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Enter Ingredients</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-4">
            {ingredients.map((ingredient, index) => (
              <div key={index} className="grid grid-cols-1 md:grid-cols-12 gap-4">
                <div className="md:col-span-7">
                  <label className="block text-sm font-medium text-gray-700">Ingredient</label>
                  <Input
                    value={ingredient.item}
                    onChange={(e) => handleIngredientChange(index, "item", e.target.value)}
                    placeholder="e.g. Flour, Sugar, Eggs"
                    className="mt-1"
                  />
                </div>
                <div className="md:col-span-4">
                  <label className="block text-sm font-medium text-gray-700">
                    Quantity <span className="text-xs text-gray-500 font-normal">(Optional)</span>
                  </label>
                  <Input
                    value={ingredient.quantity}
                    onChange={(e) => handleIngredientChange(index, "quantity", e.target.value)}
                    placeholder="e.g. 1 lb, 2 cups, 12 count"
                    className="mt-1"
                  />
                </div>
                <div className="md:col-span-1 flex items-end">
                  <Button
                    type="button"
                    onClick={() => removeIngredient(index)}
                    variant="destructive"
                    size="sm"
                    disabled={ingredients.length === 1}
                    className="w-full md:w-auto"
                  >
                    <Trash2 className="w-4 h-4 md:mr-0 mr-1" />
                    <span className="md:hidden">Remove</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
          
          {/* Mobile-friendly action buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Button
              type="button"
              onClick={addIngredient}
              variant="outline"
              className="flex-1 sm:flex-none"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Ingredient
            </Button>
            
            <Button
              type="submit"
              className="flex-1 sm:flex-none"
            >
              Compare Prices
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
