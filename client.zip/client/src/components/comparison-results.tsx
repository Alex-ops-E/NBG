import { Card, CardContent } from "@/components/ui/card";
import { BasketItem } from "@/pages/home";

// Display price per unit from API data or calculate it if not available
const renderPricePerUnit = (item: BasketItem): JSX.Element => {
  // If the API provided a pricePerUnit, use it
  if (item.pricePerUnit) {
    // Handle case where pricePerUnit is an object
    let pricePerUnitStr = '';
    
    if (typeof item.pricePerUnit === 'object' && item.pricePerUnit !== null) {
      const price = item.pricePerUnit.price;
      const unit = item.pricePerUnit.unit;
      pricePerUnitStr = `$${price || 0}/${unit || 'unit'}`;
    } else {
      pricePerUnitStr = item.pricePerUnit as string;
    }
      
    return (
      <div className="text-xs font-medium text-gray-600 mt-1 bg-gray-50 px-1.5 py-0.5 rounded inline-block">
        {pricePerUnitStr}
      </div>
    );
  }
  
  // If API provided size but not pricePerUnit, calculate it
  if (item.size) {
    // Try to extract quantity from the size string
    const quantityMatch = item.size.toLowerCase().match(/(\d+(?:\.\d+)?)\s*(oz|ounce|fl\s*oz|fluid\s*ounce|lb|pound|g|gram|ml|l|liter|cup|count|ct|pkg|package|gal|gallon)/);
    
    if (quantityMatch) {
      const [, amount, unit] = quantityMatch;
      const numericAmount = parseFloat(amount);
      
      if (!isNaN(numericAmount) && numericAmount > 0) {
        // Normalize units for consistent display
        let normalizedUnit = unit;
        if (unit === 'ounce') normalizedUnit = 'oz';
        if (unit === 'fl oz' || unit === 'fluid ounce' || unit.includes('fl')) normalizedUnit = 'Fl Oz';
        if (unit === 'pound') normalizedUnit = 'lb';
        if (unit === 'gram') normalizedUnit = 'g';
        if (unit === 'liter') normalizedUnit = 'l';
        if (unit === 'ct' || unit === 'count') normalizedUnit = 'ct';
        if (unit === 'pkg' || unit === 'package') normalizedUnit = 'pkg';
        if (unit === 'gallon') normalizedUnit = 'gal';
        
        const pricePerUnit = (item.price / numericAmount).toFixed(2);
        
        return (
          <div className="text-xs font-medium text-gray-600 mt-1 bg-gray-50 px-1.5 py-0.5 rounded inline-block">
            ${pricePerUnit} / {normalizedUnit}
          </div>
        );
      }
    }
  }
  
  // Default case, if we can't determine price per unit
  return <></>;
};

interface ComparisonResultsProps {
  data: {
    walmart: {
      basket: BasketItem[];
      total: number;
    };
    amazon: {
      basket: BasketItem[];
      total: number;
    };
  };
}

export default function ComparisonResults({ data }: ComparisonResultsProps) {
  const { walmart, amazon } = data;
  
  // Determine the cheapest retailer
  let cheapestRetailer = "amazon";
  let cheapestTotal = amazon.total;
  
  if (walmart.total <= cheapestTotal) {
    cheapestRetailer = "walmart";
    cheapestTotal = walmart.total;
  }
  
  // Calculate price differences
  const getPriceDifference = (total: number) => {
    return Math.abs(total - cheapestTotal).toFixed(2);
  };
  
  const retailerIcons: Record<string, string> = {
    walmart: "fas fa-store-alt",
    amazon: "fab fa-amazon",
  };

  return (
    <div className="space-y-6">
      {/* Results Header */}
      <div className="mb-4">
        <h2 className="text-lg font-medium text-gray-900">Price Comparison Results</h2>
      </div>

      {/* Results Summary */}
      <Card className="bg-white shadow rounded-lg overflow-hidden">
        <CardContent className="p-6 border-b border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Walmart Summary */}
            <div className="border rounded-lg p-4 bg-gradient-to-br from-[#0071DC]/5 to-[#0071DC]/10">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#0071DC]/10 mr-3">
                    <i className="fas fa-store text-[#0071DC]"></i>
                  </span>
                  <h3 className="text-lg font-medium text-gray-900">Walmart</h3>
                </div>
                {cheapestRetailer === "walmart" && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    <i className="fas fa-trophy mr-1"></i> Best Value
                  </span>
                )}
              </div>
              <div className="mt-2">
                <p className="text-sm text-gray-500">Total for {walmart.basket.length} items</p>
                <p className="text-2xl font-bold text-gray-900">${walmart.total.toFixed(2)}</p>
                {cheapestRetailer !== "walmart" && (
                  <p className="text-sm text-red-600">${getPriceDifference(walmart.total)} more expensive</p>
                )}
              </div>
              <a 
                href={"https://www.walmart.com"} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="mt-4 w-full bg-[#0071DC] hover:bg-blue-800 text-white font-medium py-2 px-4 rounded inline-flex items-center justify-center"
              >
                <i className="fas fa-shopping-cart mr-2"></i>
                <span>Shop at Walmart</span>
              </a>
            </div>

            {/* Amazon Summary */}
            <div className="border rounded-lg p-4 bg-gradient-to-br from-[#FF9900]/5 to-[#FF9900]/10">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#FF9900]/10 mr-3">
                    <i className="fab fa-amazon text-[#FF9900]"></i>
                  </span>
                  <h3 className="text-lg font-medium text-gray-900">Amazon</h3>
                </div>
                {cheapestRetailer === "amazon" && (
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    <i className="fas fa-trophy mr-1"></i> Best Value
                  </span>
                )}
              </div>
              <div className="mt-2">
                <p className="text-sm text-gray-500">Total for {amazon.basket.length} items</p>
                <p className="text-2xl font-bold text-gray-900">${amazon.total.toFixed(2)}</p>
                {cheapestRetailer !== "amazon" && (
                  <p className="text-sm text-red-600">${getPriceDifference(amazon.total)} more expensive</p>
                )}
              </div>
              <a 
                href={"https://www.amazon.com"} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="mt-4 w-full bg-[#FF9900] hover:bg-orange-600 text-white font-medium py-2 px-4 rounded inline-flex items-center justify-center"
              >
                <i className="fas fa-shopping-cart mr-2"></i>
                <span>Shop at Amazon</span>
              </a>
            </div>
          </div>
        </CardContent>

        {/* Results Table */}
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Item
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Quantity
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Walmart Price
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Amazon Price
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Best Deal
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {walmart.basket.map((item, index) => {
                const amazonItem = amazon.basket[index];
                
                // Ensure we're comparing numeric values and handle any NaN cases
                const walmartPrice = parseFloat(item.price.toString()) || 0;
                const amazonPrice = parseFloat(amazonItem.price.toString()) || 0;
                
                // Determine the best retailer based on price
                let bestRetailer = "amazon";
                let bestPrice = amazonPrice;
                let bestItem = amazonItem;
                
                if (walmartPrice < bestPrice) {
                  bestRetailer = "walmart";
                  bestPrice = walmartPrice;
                  bestItem = item;
                }
                
                // Map of retailer to color for styling
                const retailerColors: Record<string, string> = {
                  walmart: "#0071DC",
                  amazon: "#FF9900"
                };
                
                // Generate display name for retailer
                const getRetailerDisplayName = (retailer: string) => {
                  return retailer.charAt(0).toUpperCase() + retailer.slice(1);
                };
                
                return (
                  <tr key={index}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 bg-gray-100 rounded-md flex items-center justify-center">
                          <i className="fas fa-shopping-basket text-gray-500"></i>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{item.item}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{item.quantity}</div>
                    </td>
                    
                    {/* Walmart Price */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900 font-medium">${item.price.toFixed(2)}</div>
                      {renderPricePerUnit(item)}
                      {item.size && (
                        <div className="text-xs text-gray-500 mt-1">{item.size}</div>
                      )}
                      <a href={item.url} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 hover:underline flex items-center mt-1">
                        <i className="fas fa-external-link-alt mr-1 text-xs"></i>
                        Search at Walmart
                      </a>
                    </td>
                    
                    {/* Amazon Price */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900 font-medium">${amazonItem.price.toFixed(2)}</div>
                      {renderPricePerUnit(amazonItem)}
                      {amazonItem.size && (
                        <div className="text-xs text-gray-500 mt-1">{amazonItem.size}</div>
                      )}
                      {amazonItem.url && (
                        <a href={amazonItem.url} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-600 hover:underline flex items-center mt-1">
                          <i className="fas fa-external-link-alt mr-1 text-xs"></i>
                          View at Amazon
                        </a>
                      )}
                    </td>
                    
                    {/* Best Deal */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-[${retailerColors[bestRetailer]}] bg-opacity-10 text-[${retailerColors[bestRetailer]}]`}>
                        <i className={`${retailerIcons[bestRetailer]} mr-1`}></i>
                        {getRetailerDisplayName(bestRetailer)}
                      </span>
                    </td>
                    
                    {/* Action */}
                    <td className="px-6 py-4 whitespace-nowrap">
                      <a 
                        href={bestItem.url} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className={`inline-flex items-center px-3 py-1 rounded-md text-xs font-medium text-white bg-[${retailerColors[bestRetailer]}] hover:opacity-90`}
                      >
                        <i className="fas fa-shopping-cart mr-1"></i>
                        {bestRetailer === "amazon" ? "Buy Now" : `Search ${getRetailerDisplayName(bestRetailer)}`}
                      </a>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}