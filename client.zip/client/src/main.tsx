import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add Font Awesome
const script = document.createElement("script");
script.src = "https://kit.fontawesome.com/a01cd8a242.js";
script.crossOrigin = "anonymous";
document.head.appendChild(script);

// Function to remove Replit banner
function removeReplitBanner() {
  // Try different selectors that might match the Replit banner
  const selectors = [
    'div[class*="style_replit-badge-container"]',
    'div[class*="replit-badge-container"]',
    'iframe[src*="replit.com"]',
    'div[role="dialog"][aria-modal="true"]',
    'div[class*="fixed"][class*="bottom-0"] button'
  ];

  // Remove any matching elements
  for (const selector of selectors) {
    const elements = document.querySelectorAll(selector);
    elements.forEach(el => {
      // Try to find parent dialog or modal
      let parent = el as HTMLElement;
      let depth = 0;
      while (parent && depth < 5) {
        if (parent.getAttribute('role') === 'dialog' || 
            parent.getAttribute('aria-modal') === 'true' ||
            (parent.classList && 
             (parent.classList.contains('fixed') || 
              parent.classList.contains('absolute')))) {
          parent.remove();
          return;
        }
        const parentEl = parent.parentElement;
        if (!parentEl) break;
        parent = parentEl;
        depth++;
      }
      
      // If no suitable parent found, remove the element itself
      el.remove();
    });
  }
}

// Run initially and then periodically
setTimeout(() => {
  removeReplitBanner();
  // Run periodically to catch any banners that might appear later
  setInterval(removeReplitBanner, 2000);
}, 1000);

createRoot(document.getElementById("root")!).render(<App />);
